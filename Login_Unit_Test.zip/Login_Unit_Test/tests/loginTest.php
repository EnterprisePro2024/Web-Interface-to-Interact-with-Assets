<?php
use PHPUnit\Framework\TestCase;

class LoginTest extends TestCase
{
    
    public function testSuccessfulLogin() {

        session_start();
        // Simulate a successful login
        $_SESSION['login'] = true;
        $_SESSION['user_id'] = '5'; 
        $_SESSION['department_id'] = '1';
        $_SESSION['email'] = 'testuser@example.com';
        $_SESSION['password'] = 'passsword';
        $_SESSION['type'] = 'General User';
    
    
        // Check the expected redirection URL based on the user type
        // If the type is admin it takes you to the admin page else it takes you to the general
        // user page. 
        $redirectUrl = $_SESSION['type'] === 'Admin' ? '../admin/index.php' : 'home.php';
    
        // This assertion the redirect url and the getredirectURL method makes sure the 
        // redirect url is retrieved correctly. 
        $this->assertEquals($redirectUrl, $this->getRedirectUrl());
    }
    
    // Helper method to retrieve the redirection URL that is mocked up in the test
    private function getRedirectUrl() {
        
        return 'home.php'; 
    }
}

?>

    